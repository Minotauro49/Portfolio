Get started: 

step 1:	Double click on the (Trader.exe - Shortcut) file to open it or navigate to (Auto Trade) then execute (Trader.exe) file

step 3: Login using your ASX account credentials


